// scripts.js

// Event listener for the download button
document.getElementById("downloadBtn").addEventListener("click", function () {
    alert("Thank you for downloading Signal!");
});
